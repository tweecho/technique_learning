outFile = open('sample.txt', 'w')
outFile.write('My first output file!')
outFile.close()



file = open('a.txt', 'w')
file.write("This is the first line")
file.close()