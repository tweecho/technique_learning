def f():
    print('In function f')
    print('When does this print?')
f()
