def product(nums):     #Play Computer Error Exercise 
    for n in nums:     
        prod = 1        
        prod = prod*n   
    return prod         
