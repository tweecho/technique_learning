'''Test yourself again:  what happens?'''

nums = list()
i = 4
while (i < 9):
    nums.append(i)
    i = i+2
print(nums)
