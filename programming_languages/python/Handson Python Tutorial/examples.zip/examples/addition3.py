'''Two numeric inputs, with immediate conversion'''

x = int(input("Enter a number: "))
y = int(input("Enter a second number: "))
print('The sum of ', x, ' and ', y, ' is ', x+y, '.', sep='')

"""Excercise P30"""
print('The sum of {} and {} is {}'.format(x, y, x+y))